


 /******************************************************************************
 *
 * Module: dc motor
 *
 * File Name: dc_motor.c
 *
 * Description: source file for the dc motor driver
 *
 * Author: Abdelrahman Ibrahim
 *
 *******************************************************************************/
#include "dc_motor.h"
#include "pwm.h"



/*
 * Description :
 * function responsible for initialize dc-motor
 */
void DcMotor_Init(void){
	/* The Function responsible for setup the direction for the two
motor pins through the GPIO driver. */
		GPIO_setupPinDirection(MOTOR_PORT_CONTROL, MOTOR_PIN0_CONTROL, PIN_OUTPUT);
		GPIO_setupPinDirection(MOTOR_PORT_CONTROL, MOTOR_PIN1_CONTROL, PIN_OUTPUT);


		/* Motor is stop at the beginning */
		GPIO_writePin(MOTOR_PORT_CONTROL, MOTOR_PIN0_CONTROL, LOGIC_LOW);
		GPIO_writePin(MOTOR_PORT_CONTROL, MOTOR_PIN1_CONTROL, LOGIC_HIGH);
}

/*
 * The function responsible for rotate the DC Motor CW/ or A-CW or
stop the motor based on the state input state value.
➢ Send the required duty cycle to the PWM driver based on the
required speed value.
 */
void DcMotor_Rotate(DcMotor_State state,uint8 speed){

	switch(state){
	case motor_stop:
		GPIO_writePin(MOTOR_PORT_CONTROL, MOTOR_PIN0_CONTROL, LOGIC_LOW);
		GPIO_writePin(MOTOR_PORT_CONTROL, MOTOR_PIN1_CONTROL, LOGIC_LOW);
		break;
	case motor_A_CW:
		GPIO_writePin(MOTOR_PORT_CONTROL, MOTOR_PIN0_CONTROL, LOGIC_LOW);
		GPIO_writePin(MOTOR_PORT_CONTROL, MOTOR_PIN1_CONTROL, LOGIC_HIGH);
		break;
	case motor_CW:
		GPIO_writePin(MOTOR_PORT_CONTROL, MOTOR_PIN0_CONTROL, LOGIC_HIGH);
		GPIO_writePin(MOTOR_PORT_CONTROL, MOTOR_PIN1_CONTROL, LOGIC_LOW);
		break;
	}

	uint8 duty_cycle= (uint8) (  (speed/100.0f)*255 ) ;
	PWM_Timer0_Start(duty_cycle); //generate duty cycle
}
